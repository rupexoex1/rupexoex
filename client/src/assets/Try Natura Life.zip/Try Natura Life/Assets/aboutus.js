// DOM Elements
const menuToggle = document.getElementById('menuToggle');
const offCanvasMenu = document.getElementById('offCanvasMenu');
const closeMenu = document.getElementById('closeMenu');
const cartToggle = document.getElementById('cartToggle');
const offCanvasCart = document.getElementById('offCanvasCart');
const closeCart = document.getElementById('closeCart');
const overlay = document.getElementById('overlay');
const navbar = document.getElementById('navbar');
const cartCount = document.getElementById('cartCount');
const cartBadge = document.getElementById('cartBadge');
const cartTotal = document.getElementById('cartTotal');
const emptyCart = document.getElementById('emptyCart');
const cartItems = document.getElementById('cartItems');
const youMayLike = document.getElementById('youMayLike');

// Cart state
// let cart = [];
// let total = 0;

// Menu Toggle Functionality
menuToggle.addEventListener('click', () => {
    menuToggle.classList.toggle('active');
    offCanvasMenu.classList.toggle('active');
    overlay.classList.toggle('active');
    document.body.style.overflow = offCanvasMenu.classList.contains('active') ? 'hidden' : 'auto';
});

closeMenu.addEventListener('click', () => {
    menuToggle.classList.remove('active');
    offCanvasMenu.classList.remove('active');
    overlay.classList.remove('active');
    document.body.style.overflow = 'auto';
});

// Cart Toggle Functionality
cartToggle.addEventListener('click', () => {
    offCanvasCart.classList.toggle('active');
    overlay.classList.toggle('active');
    document.body.style.overflow = offCanvasCart.classList.contains('active') ? 'hidden' : 'auto';
});

closeCart.addEventListener('click', () => {
    offCanvasCart.classList.remove('active');
    overlay.classList.remove('active');
    document.body.style.overflow = 'auto';
});

// Overlay Click to Close
overlay.addEventListener('click', () => {
    menuToggle.classList.remove('active');
    offCanvasMenu.classList.remove('active');
    offCanvasCart.classList.remove('active');
    overlay.classList.remove('active');
    document.body.style.overflow = 'auto';
});

// Sticky Navbar Effect
let lastScrollTop = 0;
window.addEventListener('scroll', () => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    if (scrollTop > lastScrollTop && scrollTop > 100) {
        navbar.style.transform = 'translateY(-100%)';
    } else {
        navbar.style.transform = 'translateY(0)';
    }
    
    lastScrollTop = scrollTop;
});


// Smooth scrolling for menu links
document.querySelectorAll('.menu-items a').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        menuToggle.classList.remove('active');
        offCanvasMenu.classList.remove('active');
        overlay.classList.remove('active');
        document.body.style.overflow = 'auto';
        const targetSection = document.querySelector(targetId);
        if (targetSection) {
            targetSection.scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// Search functionality
document.querySelector('.search-btn').addEventListener('click', () => {
    const searchTerm = prompt('What are you looking for?');
    if (searchTerm) {
        alert(`Searching for: ${searchTerm}`);
    }
});

// Chat widget functionality
document.querySelector('.chat-btn').addEventListener('click', () => {
    alert('Chat feature coming soon! Contact us at support@nutralife.com');
});

Checkout
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('checkout-btn')) {
        if (cart.length === 0) {
            alert('Your cart is empty!');
            return;
        }
        alert(`Proceeding to checkout with ${cart.length} item(s) totaling $${total.toFixed(2)}`);
    }
});

// CSS Injection for Cart Items
const cartItemStyles = `
.cart-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 0;
    border-bottom: 1px solid #eee;
}
.cart-item:last-child {
    border-bottom: none;
}
.cart-item-image img {
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 5px;
}
.cart-item-details {
    flex-grow: 1;
    margin-left: 15px;
}
.cart-item-details h4 {
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 5px;
}
.cart-item-rating {
    display: flex;
    align-items: center;
    gap: 5px;
    margin-bottom: 5px;
}
.cart-item-price {
    font-size: 13px;
    color: #666;
    margin-bottom: 5px;
}
.stock-status {
    font-size: 12px;
    color: #333;
    margin-bottom: 10px;
}
.cart-item-actions {
    display: flex;
    align-items: center;
    gap: 10px;
}
.quantity-controls {
    display: flex;
    align-items: center;
    gap: 5px;
}
.quantity-btn {
    width: 25px;
    height: 25px;
    border: 1px solid #ddd;
    background: white;
    cursor: pointer;
    border-radius: 3px;
    font-size: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.quantity-btn:hover {
    background: #f5f5f5;
}
.quantity {
    font-weight: 600;
    min-width: 20px;
    text-align: center;
}
.remove-btn {
    background: #ff4757 !important;
    color: white !important;
    border-color: #ff4757 !important;
    display: flex;
    align-items: center;
    justify-content: center;
}
.remove-btn:hover {
    background: #ff3838 !important;
}
`;
const styleSheet = document.createElement('style');
styleSheet.textContent = cartItemStyles;
document.head.appendChild(styleSheet);






























